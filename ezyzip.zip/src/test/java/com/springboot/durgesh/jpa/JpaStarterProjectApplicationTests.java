package com.springboot.durgesh.jpa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JpaStarterProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
